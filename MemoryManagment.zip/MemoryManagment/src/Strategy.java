public class Strategy {
}
