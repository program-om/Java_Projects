public class Frame {
    Page page = new Page();
    int orderOfLastAccess;
    String haloo = "hallooo";

    public Frame() {
        orderOfLastAccess = 0;
    }
}
