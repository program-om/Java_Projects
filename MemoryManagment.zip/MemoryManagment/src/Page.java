public class Page {
    public int pageNum;
    public int processNum;
}
